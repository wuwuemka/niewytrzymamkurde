import math
def pkwadratu():
    a = float(input('daj a '))
    print('wynik to: ',a**2)
def pprostokata():
    a = float(input('daj a '))
    b = float(input('daj b '))
    print('wynik to: ',a*b)
def prownolegloboku():
    a = float(input('daj a '))
    h = float(input('daj h '))
    print('wynik to: ',a*h)
def ptrapezu():
    a = float(input('daj a '))
    b = float(input('daj b '))
    h = float(input('daj h '))
    print('wynik to: ',(a+b)*h/2)
def ptrojkata():
    a = float(input('daj a '))
    h = float(input('daj h '))
    print('wynik to: ',a*h/2)
def ptrojkatarownobocznego():
    a = float(input('daj a '))
    print('wynik to: ',(a**2)*math.sqrt(3)/2)
def pkola():
    r = float(input('daj r '))
    print('wynik to: ',math.pi*r**2)
def prombu():
    e = float(input('daj e '))
    f = float(input('daj f '))
    print('wynik to: ',e*f/2)
def pitagoras():
    a = float(input('daj a '))
    b = float(input('daj b '))
    print('wynik to: ',math.sqrt(a**2+b**2))
def przkwadratu():
    a = float(input('daj a '))
    print('wynik to: ',a*math.sqrt(2))
def htrojkatarownobocznego():
    a = float(input('daj a '))
    print('wynik to: ',a/2*math.sqrt(3))
def obwkwadratu():
    a = float(input('daj a '))
    print('wynik to: ',4*a)
def obwprostokata():
    a = float(input('daj a '))
    b = float(input('daj b '))
    print('wynik to: ',a*2+b*2)
def obwrownolegloboku():
    a = float(input('daj a '))
    b = float(input('daj b '))
    print('wynik to: ',a*2+b*2)
def obwtrapezu():
    a = float(input('daj a '))
    b = float(input('daj b '))
    c = float(input('daj c '))
    d = float(input('daj d '))
    print('wynik to: ',a+b+c+d)
def obwtrojkata():
    a = float(input('daj a '))
    b = float(input('daj b '))
    c = float(input('daj c '))
    print('wynik to: ',a+b+c)
def obwtrojkatarownobocznego():
    a = float(input('daj a '))
    print('wynik to: ',a*3)
def obwkola():
    r = float(input('daj a '))
    print('wynik to: ',2*math.pi*r)
def obwrombu():
    a = float(input('daj a '))
    print('wynik to: ',4*a)
def vszescianu():
    a = float(input('daj a '))
    print('wynik to: ',a**3)
def vprostopadloscianu():
    a = float(input('daj a '))
    b = float(input('daj b '))
    c = float(input('daj c '))
    print('wynik to: ',a*b*c)
def vgraniastoslupa():
    h = float(input('daj h '))
    pp = float(input('daj pole podstawy '))
    print('wynik to: ',pp*h)
def vostroslupa():
    h = float(input('daj r '))
    pp = float(input('daj pole podstawy '))
    print('wynik to: ',1/3*pp*h)
def vwalca():
    r = float(input('daj r '))
    h = float(input('daj h '))
    print('wynik to: ',math.pi*r**2*h)
def vstozka():
    r = float(input('daj r '))
    h = float(input('daj h '))
    print('wynik to: ',1/3*math.pi*r**2*h)
def vkuli():
    r = float(input('daj r '))
    print('wynik to: ',4/3*math.pi*r**3)

def pcszescianu():
    a = float(input('daj a '))
    print('wynik to: ',6*a**2)
def pcprostopadloscianu():
    a = float(input('daj a '))
    b = float(input('daj b '))
    c = float(input('daj c '))
    print('wynik to: ',2*a*b+2*a*c+2*b*c)
def pcgraniastoslupa():
    pb = float(input('daj pole powierzchni bocznej '))
    pp = float(input('daj pole podstawy '))
    print('wynik to: ',pb+pp*2)
def pcostroslupa():
    pp = float(input('daj pole podstawy '))
    pb = float(input('daj pole powierzchni bocznej '))
    print('wynik to: ',pp+pb)
def pcwalca():
    r = float(input('daj r '))
    h = float(input('daj h '))
    print('wynik to: ',2*math.pi*r**2+2*math.pi*r*h)
def pcstożka():
    r = float(input('daj r '))
    l = float(input('daj l '))
    print('wynik to: ',math.pi*r*(r+l))
def pckuli():
    r = float(input('daj r '))
    print('wynik to: ',4*math.pi*r**2)